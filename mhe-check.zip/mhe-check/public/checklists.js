/*
 * MHE pre-use check lists.
 *
 * Based on HSE L117 "Rider-operated lift trucks – Operator training and safe use"
 * (ACOP, pre-use / daily checks), PUWER 1998 & LOLER 1998 duties, and typical
 * manufacturer daily-check schedules. Review against each truck's manufacturer
 * handbook and your own risk assessment – edit freely.
 *
 * critical: true  -> a fault means the truck must NOT be used (taken out of service)
 * na: true        -> operator may mark "N/A" (e.g. item only on some trucks)
 */
(function () {
  const I = (id, text, opts = {}) => ({ id, text, critical: !!opts.critical, na: !!opts.na, help: opts.help || "" });

  // ---------- shared building blocks ----------
  const walkaround = [
    I("tyres", "Tyres & wheels – no cuts, chunks missing, flat spots or excessive wear; wheel nuts secure", { critical: true }),
    I("forks", "Forks – not cracked, bent or worn at the heel; fork locking pins in place", { critical: true }),
    I("leaks", "No hydraulic oil, fuel, coolant or battery acid leaks on or under the truck", { critical: true }),
    I("body", "Bodywork, panels, guards and covers secure and undamaged"),
    I("plate", "Data / rated capacity plate fitted and readable; warning labels in place", { critical: true }),
  ];

  const mast = [
    I("mast", "Mast – no visible damage; channels & rollers OK, nothing trapped", { critical: true }),
    I("chains", "Lift chains – even tension, lubricated, no damaged / stiff links; anchor pins secure", { critical: true }),
    I("hoses", "Hydraulic hoses & pipes – no chafing, splits or leaks", { critical: true }),
    I("backrest", "Load backrest extension secure and undamaged", { critical: true }),
    I("guard", "Overhead guard secure and undamaged", { critical: true }),
    I("attachment", "Attachment (side-shift / fork positioner) secure and working", { na: true }),
  ];

  const battery = [
    I("battery", "Battery charged (check gauge); cables, plug & connector undamaged; battery secure and cover closed", { critical: true, na: true }),
  ];

  const cab = [
    I("seat", "Seat secure and adjusts; seat switch (if fitted) stops drive when you leave the seat"),
    I("belt", "Seat belt / operator restraint fitted, latches and releases correctly", { critical: true }),
    I("steps", "Steps, floor & handholds clean, secure and not slippery"),
    I("mirrors", "Mirrors / cameras clean and undamaged", { na: true }),
    I("display", "Display – no warning lights or fault codes; hour meter working"),
  ];

  const functional = [
    I("horn", "Horn works", { critical: true }),
    I("lights", "Lights, beacon / blue spot and reversing alarm work", { na: true }),
    I("drive", "Forward / reverse drive controls work smoothly and correctly", { critical: true }),
    I("brakes", "Service brake stops the truck effectively", { critical: true }),
    I("parkbrake", "Parking brake holds the truck", { critical: true }),
    I("steering", "Steering smooth, no excessive play or noise", { critical: true }),
    I("hydraulics", "Lift, lower, tilt & side-shift controls work smoothly and return to neutral; no jerking", { critical: true }),
    I("estop", "Emergency stop / isolator cuts power", { critical: true }),
  ];

  const finish = [
    I("extinguisher", "Fire extinguisher (if fitted) present, secure and in date", { na: true }),
    I("clean", "Truck clean, no loose items in cab or on forks"),
  ];

  // ---------- truck types ----------
  const TYPES = {
    COUNTERBALANCE: {
      label: "Counterbalance",
      short: "CB",
      sections: [
        { title: "Walk-around", items: [...walkaround, I("counterweight", "Counterweight secure, no damage; tow pin secure (if fitted)", { critical: true })] },
        { title: "Mast & forks", items: [...mast, I("tilt", "Tilt rams secure, no leaks", { critical: true })] },
        { title: "Power source", items: [
          ...battery,
          I("lpg", "LPG – cylinder secure in cradle, valve & hose undamaged, no smell of gas", { critical: true, na: true }),
          I("fluids", "Diesel / LPG trucks – engine oil, coolant & fuel levels OK", { na: true }),
        ] },
        { title: "Cab", items: cab },
        { title: "Function tests", items: functional },
        { title: "Finish", items: finish },
      ],
    },
    REACH: {
      label: "Reach",
      short: "RT",
      sections: [
        { title: "Walk-around", items: [...walkaround,
          I("legs", "Stabiliser legs & load wheels – undamaged, free of debris / shrink-wrap", { critical: true })] },
        { title: "Mast & forks", items: [...mast,
          I("reach", "Reach mechanism (moving mast / pantograph) extends and retracts smoothly", { critical: true }),
          I("tilt", "Fork tilt works", { critical: true })] },
        { title: "Power source", items: battery },
        { title: "Operator compartment", items: [
          I("deadman", "Dead-man / foot pedal works – truck will not drive when released", { critical: true }),
          I("seat", "Seat / backrest secure; seat switch works (if fitted)"),
          I("steps", "Step, floor & handholds clean, secure and not slippery"),
          I("mirrors", "Mirrors / cameras / height indicator clean and working", { na: true }),
          I("display", "Display – no warning lights or fault codes; hour meter working"),
        ] },
        { title: "Function tests", items: functional },
        { title: "Finish", items: finish },
      ],
    },
    FLEXI: {
      label: "Flexi (articulated)",
      short: "FLX",
      sections: [
        { title: "Walk-around", items: [...walkaround,
          I("artic", "Articulation joint – no cracks, excessive play or leaks", { critical: true })] },
        { title: "Mast & forks", items: [...mast,
          I("rotate", "Head / mast rotation swings smoothly through full range both ways", { critical: true })] },
        { title: "Power source", items: [
          ...battery,
          I("lpg", "LPG – cylinder secure, valve & hose undamaged, no smell of gas", { critical: true, na: true }),
        ] },
        { title: "Cab", items: [...cab,
          I("cabguard", "Cab guards / side restraints secure", { critical: true })] },
        { title: "Function tests", items: [...functional,
          I("proximity", "Aisle guidance / speed limit / proximity sensors working (if fitted)", { na: true })] },
        { title: "Finish", items: finish },
      ],
    },
    PPT: {
      label: "PPT (pedestrian)",
      short: "PPT",
      sections: [
        { title: "Walk-around", items: [
          I("wheels", "Drive wheel, castors & load rollers – undamaged, turn freely, no debris / wrap", { critical: true }),
          I("forks", "Forks – not cracked, bent or twisted", { critical: true }),
          I("leaks", "No hydraulic oil or battery leaks", { critical: true }),
          I("body", "Covers and guards secure and undamaged"),
          I("plate", "Capacity plate fitted and readable", { critical: true }),
          I("backrest", "Load backrest (if fitted) secure", { na: true }),
        ] },
        { title: "Power source", items: [
          I("battery", "Battery charged; charging lead / connector undamaged; cover closed", { critical: true }),
        ] },
        { title: "Tiller & controls", items: [
          I("tiller", "Tiller arm – undamaged, springs back up and applies the brake when released", { critical: true }),
          I("belly", "Belly button (anti-crush reverse switch) works", { critical: true }),
          I("isolator", "Emergency isolator / red key switch cuts power", { critical: true }),
          I("horn", "Horn works", { critical: true }),
          I("drive", "Forward / reverse and speed control work correctly", { critical: true }),
          I("brakes", "Brakes stop the truck effectively", { critical: true }),
          I("steering", "Steering smooth", { critical: true }),
          I("hydraulics", "Lift & lower work smoothly", { critical: true }),
          I("display", "Display – no fault codes", { na: true }),
        ] },
        { title: "Finish", items: [I("clean", "Truck clean, nothing loose on forks")] },
      ],
    },
    PPT_RIDE: {
      label: "PPT (ride-on)",
      short: "RPPT",
      sections: [
        { title: "Walk-around", items: [
          I("wheels", "Drive wheel, castors & load rollers – undamaged, turn freely, no debris / wrap", { critical: true }),
          I("forks", "Forks – not cracked, bent or twisted", { critical: true }),
          I("leaks", "No hydraulic oil or battery leaks", { critical: true }),
          I("body", "Covers and guards secure and undamaged"),
          I("plate", "Capacity plate fitted and readable", { critical: true }),
        ] },
        { title: "Power source", items: [
          I("battery", "Battery charged; charging lead / connector undamaged; cover closed", { critical: true }),
        ] },
        { title: "Platform", items: [
          I("platform", "Platform folds down / up correctly, floor mat undamaged", { critical: true }),
          I("sidearms", "Side arms / guards lock in place", { critical: true }),
          I("platswitch", "Platform presence (dead-man) switch works", { critical: true }),
        ] },
        { title: "Tiller & controls", items: [
          I("tiller", "Tiller arm – undamaged, springs back and brakes when released", { critical: true }),
          I("belly", "Belly button (anti-crush reverse switch) works", { critical: true }),
          I("isolator", "Emergency isolator / red key switch cuts power", { critical: true }),
          I("horn", "Horn works", { critical: true }),
          I("drive", "Forward / reverse and speed control work correctly", { critical: true }),
          I("brakes", "Brakes stop the truck effectively", { critical: true }),
          I("steering", "Steering smooth", { critical: true }),
          I("hydraulics", "Lift & lower work smoothly", { critical: true }),
          I("display", "Display – no fault codes", { na: true }),
        ] },
        { title: "Finish", items: [I("clean", "Truck clean, nothing loose on forks or platform")] },
      ],
    },
  };

  // Settings for random spot-check photos
  const SPOT_PHOTOS = { min: 1, max: 3, wholeTruckChance: 0.35 };
  // Checks faster than this are flagged as "rushed" in the manager portal
  const RUSHED_SECONDS = 150;
  const SHIFTS = ["Early", "Late", "Night", "Days"];

  const api = { TYPES, SPOT_PHOTOS, RUSHED_SECONDS, SHIFTS };
  if (typeof window !== "undefined") window.MHE = api;
  if (typeof module !== "undefined") module.exports = api;
})();
