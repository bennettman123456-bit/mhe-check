/* MHE Pre-Use Check – operator app */
(function () {
  const { TYPES, SPOT_PHOTOS, SHIFTS } = window.MHE;
  const $app = document.getElementById("app");
  const $title = document.getElementById("title");
  const $camera = document.getElementById("camera");
  const $logout = document.getElementById("logoutBtn");

  // ---------- storage (safe) ----------
  const ls = {
    get(k, d = null) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
    del(k) { try { localStorage.removeItem(k); } catch {} },
  };

  const S = {
    token: ls.get("mhe_token"), name: ls.get("mhe_name"), shift: ls.get("mhe_shift") || "",
    truck: null, draft: null, scanner: null,
  };

  // ---------- utils ----------
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const h = (html) => { $app.innerHTML = html; window.scrollTo(0, 0); };
  const fmtTime = (iso) => new Date(iso).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  function toast(msg, ms = 2600) {
    const t = document.createElement("div"); t.className = "toast"; t.textContent = msg;
    document.body.appendChild(t); setTimeout(() => t.remove(), ms);
  }
  async function api(path, opts = {}) {
    const res = await fetch("/api/" + path, {
      method: opts.method || (opts.body ? "POST" : "GET"),
      headers: { "content-type": "application/json", ...(S.token ? { authorization: "Bearer " + S.token } : {}) },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && path !== "login") { logout(); throw new Error("Session expired – please log in again"); }
    if (!res.ok) throw new Error(data.error || "Something went wrong (" + res.status + ")");
    return data;
  }
  function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  const saveDraft = () => {
    if (!S.draft) return ls.del("mhe_draft");
    const slim = JSON.parse(JSON.stringify(S.draft, (k, v) => (k === "full" ? undefined : v)));
    ls.set("mhe_draft", slim);
  };

  function truckFromText(txt) {
    txt = String(txt || "").trim();
    try { const u = new URL(txt); const t = u.searchParams.get("truck"); if (t) return t.toUpperCase(); } catch {}
    return txt.replace(/^MHE:/i, "").trim().toUpperCase();
  }

  // ---------- login ----------
  function logout() {
    ls.del("mhe_token"); ls.del("mhe_name"); S.token = null; S.name = null; stopScanner(); viewLogin();
  }
  $logout.onclick = () => { if (!S.draft || confirm("Log out? Your unfinished check will be lost.")) { S.draft = null; saveDraft(); logout(); } };

  function viewLogin() {
    $logout.classList.add("hidden"); $title.textContent = "Pre-Use Check";
    let pin = "";
    h(`
      <div class="card center">
        <h1>Operator log in</h1>
        <p class="muted">Enter your PIN</p>
        <div class="pin-dots" id="dots"></div>
        <div class="pad" id="pad">
          ${[1,2,3,4,5,6,7,8,9].map((n) => `<button data-k="${n}">${n}</button>`).join("")}
          <button data-k="clr" style="font-size:16px">Clear</button><button data-k="0">0</button><button data-k="go" style="background:var(--accent);font-size:18px">Go</button>
        </div>
        <p id="err" class="banner bad hidden" style="margin-top:14px"></p>
      </div>
      <p class="center small muted"><a href="/manager.html">Supervisor / manager portal →</a></p>`);
    const dots = document.getElementById("dots");
    const draw = () => { dots.innerHTML = Array.from({ length: Math.max(4, pin.length) }, (_, i) => `<span class="${i < pin.length ? "on" : ""}"></span>`).join(""); };
    draw();
    const go = async () => {
      if (pin.length < 4) return;
      try {
        const r = await api("login", { body: { pin } });
        S.token = r.token; S.name = r.name; ls.set("mhe_token", r.token); ls.set("mhe_name", r.name);
        start();
      } catch (e) { const el = document.getElementById("err"); el.textContent = e.message; el.classList.remove("hidden"); pin = ""; draw(); }
    };
    document.getElementById("pad").onclick = (e) => {
      const k = e.target.dataset.k; if (!k) return;
      if (k === "clr") pin = ""; else if (k === "go") return go(); else if (pin.length < 8) pin += k;
      draw();
      if (pin.length >= 4 && pin.length === 8) go();
    };
  }

  // ---------- home ----------
  function viewHome() {
    stopScanner();
    $logout.classList.remove("hidden"); $title.textContent = "Pre-Use Check";
    const draft = ls.get("mhe_draft");
    h(`
      <div class="card">
        <h1>Hi ${esc(S.name)} 👋</h1>
        <label class="f" for="shift">Your shift</label>
        <select id="shift" class="in">
          <option value="">Choose shift…</option>
          ${SHIFTS.map((s) => `<option ${s === S.shift ? "selected" : ""}>${s}</option>`).join("")}
        </select>
      </div>
      ${draft ? `<div class="banner warn">You have an unfinished check on <b>${esc(draft.truckId)}</b>.
        <div class="row" style="margin-top:10px"><button class="btn sm" id="resume">Carry on</button><button class="btn sm ghost" id="discard">Discard</button></div></div>` : ""}
      <button class="btn big yellow" id="scan">📷 Scan truck QR code</button>
      <div class="card" style="margin-top:14px">
        <label class="f" for="manual">QR code damaged? Type the truck ID</label>
        <div class="row"><input id="manual" class="in" placeholder="e.g. FLX-01" autocapitalize="characters" style="flex:2"><button class="btn" id="go">Go</button></div>
      </div>`);
    const shiftEl = document.getElementById("shift");
    shiftEl.onchange = () => { S.shift = shiftEl.value; ls.set("mhe_shift", S.shift); };
    const needShift = () => { if (!S.shift) { toast("Choose your shift first"); shiftEl.focus(); return true; } return false; };
    document.getElementById("scan").onclick = () => { if (!needShift()) viewScan(); };
    document.getElementById("go").onclick = () => { const v = truckFromText(document.getElementById("manual").value); if (v && !needShift()) openTruck(v); };
    if (draft) {
      document.getElementById("resume").onclick = () => resumeDraft(draft);
      document.getElementById("discard").onclick = () => { if (confirm("Discard the unfinished check?")) { ls.del("mhe_draft"); viewHome(); } };
    }
  }

  // ---------- scanner ----------
  function loadScript(src) {
    return new Promise((res, rej) => { const s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = rej; document.head.appendChild(s); });
  }
  async function ensureScannerLib() {
    if (window.Html5Qrcode) return;
    try { await loadScript("https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"); }
    catch { await loadScript("https://cdn.jsdelivr.net/npm/html5-qrcode@2.3.8/html5-qrcode.min.js"); }
    if (!window.Html5Qrcode && window.__Html5QrcodeLibrary__) window.Html5Qrcode = window.__Html5QrcodeLibrary__.Html5Qrcode;
  }
  function stopScanner() {
    if (S.scanner) { const s = S.scanner; S.scanner = null; s.stop().catch(() => {}).finally(() => { try { s.clear(); } catch {} }); }
  }
  async function viewScan() {
    $title.textContent = "Scan truck";
    h(`<div class="card"><h2>Point the camera at the truck's QR code</h2><div id="reader"></div>
       <p class="small muted" id="scanMsg">Starting camera…</p></div>
       <button class="btn ghost" id="cancel">Cancel</button>`);
    document.getElementById("cancel").onclick = viewHome;
    try {
      await ensureScannerLib();
      const sc = new window.Html5Qrcode("reader");
      S.scanner = sc;
      await sc.start({ facingMode: "environment" }, { fps: 10, qrbox: { width: 240, height: 240 } }, (text) => {
        if (navigator.vibrate) navigator.vibrate(80);
        stopScanner(); openTruck(truckFromText(text));
      });
      document.getElementById("scanMsg").textContent = "Hold steady – it scans automatically.";
    } catch (e) {
      const el = document.getElementById("scanMsg");
      if (el) el.innerHTML = `<span class="banner bad" style="display:block">Couldn't start the camera. Allow camera access for this site, or go back and type the truck ID.</span>`;
    }
  }

  // ---------- truck ----------
  async function openTruck(id) {
    $title.textContent = id;
    h(`<div class="card center muted">Loading ${esc(id)}…</div>`);
    try {
      const r = await api("trucks/" + encodeURIComponent(id));
      S.truck = r.truck;
      viewTruck(r);
    } catch (e) {
      h(`<div class="banner bad">${esc(e.message)}</div><button class="btn" id="back">Back</button>`);
      document.getElementById("back").onclick = viewHome;
    }
  }

  function viewTruck(r) {
    const t = r.truck; const type = TYPES[t.type];
    const crit = r.openFaults.filter((f) => f.critical);
    let banner = "";
    if (t.status === "OFF_ROAD") banner = `<div class="banner bad">⛔ OFF ROAD – DO NOT USE.<br><span class="small">${esc(t.offRoadReason || "Taken out of service by a supervisor.")}</span></div>`;
    else if (crit.length) banner = `<div class="banner bad">⛔ DO NOT USE – open safety fault${crit.length > 1 ? "s" : ""}:<ul style="margin:6px 0 0;padding-left:18px">${crit.map((f) => `<li>${esc(f.itemText)} <span class="small">(${esc(f.reportedBy)}, ${new Date(f.reportedAt).toLocaleDateString("en-GB")})</span></li>`).join("")}</ul><div class="small" style="margin-top:6px">Speak to your supervisor before using this truck.</div></div>`;
    else if (r.openFaults.length) banner = `<div class="banner warn">⚠️ ${r.openFaults.length} minor fault(s) already reported:<ul style="margin:6px 0 0;padding-left:18px">${r.openFaults.map((f) => `<li>${esc(f.itemText)}</li>`).join("")}</ul></div>`;
    const today = r.todaysChecks.length ? `<div class="banner info small">Already checked today: ${r.todaysChecks.map((c) => `${esc(c.operatorName)} at ${fmtTime(c.submittedAt)} (${esc(c.shift)})`).join(", ")}</div>` : "";
    h(`
      <div class="card">
        <div class="truck-head">
          <div class="truck-badge">${esc(type?.short || "MHE")}</div>
          <div><h1 style="margin:0">${esc(t.id)}</h1>
          <div class="muted">${esc(type?.label || t.type)}${t.name ? " · " + esc(t.name) : ""}${t.make ? " · " + esc(t.make) : ""}</div></div>
        </div>
      </div>
      ${banner}${today}
      ${type ? `
      <div class="card">
        <label class="f" for="hours">Hour meter reading</label>
        <input id="hours" class="in" inputmode="decimal" placeholder="e.g. 10452">
        <p class="small muted">About ${type.sections.reduce((n, s) => n + s.items.length, 0)} checks. Look at each item properly – some items will ask you for a photo.</p>
      </div>
      <button class="btn big yellow" id="begin" ${t.status === "OFF_ROAD" ? "disabled" : ""}>Start pre-use check</button>`
      : `<div class="banner bad">This truck has no checklist type set. Ask a supervisor.</div>`}
      <button class="btn ghost" id="back" style="margin-top:10px">Back</button>`);
    document.getElementById("back").onclick = viewHome;
    const begin = document.getElementById("begin");
    if (begin) begin.onclick = () => {
      const hours = document.getElementById("hours").value.trim();
      if (!hours) { toast("Enter the hour meter reading"); return document.getElementById("hours").focus(); }
      newDraft(t, hours);
    };
  }

  // ---------- check flow ----------
  function newDraft(truck, hours) {
    const type = TYPES[truck.type];
    const steps = [];
    type.sections.forEach((s) => s.items.forEach((it) => steps.push({ ...it, section: s.title })));
    const nSpot = SPOT_PHOTOS.min + Math.floor(Math.random() * (SPOT_PHOTOS.max - SPOT_PHOTOS.min + 1));
    shuffle(steps.map((_, i) => i)).slice(0, nSpot).forEach((i) => (steps[i].spotPhoto = true));
    let wholeTruck = false;
    if (Math.random() < SPOT_PHOTOS.wholeTruckChance) {
      wholeTruck = true;
      const at = 1 + Math.floor(Math.random() * (steps.length - 1));
      steps.splice(at, 0, { id: "__truck", section: "Spot check", text: "Take a photo of the whole truck with its ID / QR label showing", photoOnly: true, spotPhoto: true });
    }
    S.draft = { truckId: truck.id, truckType: truck.type, truck, shift: S.shift, hours, startedAt: new Date().toISOString(), steps, idx: 0, answers: {}, wholeTruck, fast: 0 };
    saveDraft(); viewStep();
  }
  async function resumeDraft(d) {
    try {
      const r = await api("trucks/" + encodeURIComponent(d.truckId));
      S.truck = r.truck; S.draft = d; viewStep();
    } catch (e) { toast(e.message); }
  }

  function photoBlock(ans, label) {
    return `<button class="btn ${ans.photos?.length ? "ghost" : "yellow"}" id="snap">📷 ${esc(label)}</button>
      <div class="thumbs" id="thumbs">${(ans.photos || []).map((p, i) => `<img src="${p.thumb}" data-i="${i}" alt="photo ${i + 1}">`).join("")}</div>`;
  }

  function viewStep() {
    const d = S.draft; const step = d.steps[d.idx]; const n = d.steps.length;
    $title.textContent = d.truckId + " · check";
    const ans = d.answers[d.idx] || (d.answers[d.idx] = { photos: [] });
    const needSpot = step.spotPhoto && !ans.photos.length;
    const faultOpen = ans.result === "FAULT";
    h(`
      <div class="small muted">${esc(step.section)} · ${d.idx + 1} of ${n}</div>
      <div class="progress"><div style="width:${(d.idx / n) * 100}%"></div></div>
      <div class="card">
        ${step.critical ? `<span class="pill bad">SAFETY CRITICAL</span>` : ""}
        <div class="item-text">${esc(step.text)}</div>
        ${step.spotPhoto ? `<div class="spot">📸 Spot check – take a photo ${step.photoOnly ? "" : "of this item "}before you continue.</div>${photoBlock(ans, ans.photos.length ? "Retake photo" : "Take photo")}` : ""}
      </div>
      ${step.photoOnly ? `<button class="btn big" id="next" ${needSpot ? "disabled" : ""}>Next →</button>` : `
      <div class="answers ${faultOpen ? "hidden" : ""}" id="answers">
        <button class="btn ok" data-r="OK" ${needSpot ? "disabled" : ""}>✔ OK</button>
        <button class="btn bad" data-r="FAULT" ${needSpot ? "disabled" : ""}>✖ Fault</button>
        ${step.na ? `<button class="btn na" data-r="NA" ${needSpot ? "disabled" : ""}>N/A – not fitted</button>` : ""}
      </div>
      <div class="card ${faultOpen ? "" : "hidden"}" id="faultBox" style="border-left:6px solid var(--bad)">
        <h2>Report the fault</h2>
        <label class="f" for="note">What's wrong?</label>
        <textarea id="note" class="in" placeholder="Describe the fault">${esc(ans.note || "")}</textarea>
        <p class="small muted">Take at least one photo of the fault.</p>
        <button class="btn yellow" id="faultSnap">📷 Add fault photo</button>
        <div class="thumbs" id="fthumbs">${(ans.faultPhotos || []).map((p, i) => `<img src="${p.thumb}" data-i="${i}" alt="fault photo ${i + 1}">`).join("")}</div>
        <div class="row" style="margin-top:12px">
          <button class="btn ghost" id="cancelFault">Cancel</button>
          <button class="btn bad" id="saveFault">Save fault →</button>
        </div>
      </div>`}
      ${d.idx > 0 ? `<button class="btn ghost" id="prev" style="margin-top:10px">← Back</button>` : ""}`);

    d.shownAt = Date.now();
    const snap = document.getElementById("snap");
    if (snap) snap.onclick = () => takePhoto("spot", (p) => { ans.photos = [p]; saveDraft(); viewStep(); });
    const prev = document.getElementById("prev");
    if (prev) prev.onclick = () => { d.idx--; saveDraft(); viewStep(); };
    const next = document.getElementById("next");
    if (next) next.onclick = () => advance();
    bindThumbs("thumbs", ans.photos); bindThumbs("fthumbs", ans.faultPhotos || []);

    const answers = document.getElementById("answers");
    if (answers) answers.onclick = (e) => {
      const r = e.target.closest("[data-r]")?.dataset.r; if (!r) return;
      if (r === "FAULT") { ans.result = "FAULT"; ans.faultPhotos = ans.faultPhotos || []; viewStep(); return; }
      ans.result = r; ans.note = ""; ans.faultPhotos = []; ans.answeredAt = new Date().toISOString();
      if (Date.now() - d.shownAt < 1800) d.fast++; else d.fast = 0;
      if (d.fast >= 3) { d.fast = 0; toast("Slow down – physically check each item before answering.", 3500); }
      advance();
    };
    const fs = document.getElementById("faultSnap");
    if (fs) {
      fs.onclick = () => {
        ans.note = document.getElementById("note").value;
        if ((ans.faultPhotos || []).length >= 3) return toast("Max 3 photos per fault");
        takePhoto("fault", (p) => { ans.faultPhotos.push(p); saveDraft(); viewStep(); });
      };
      document.getElementById("note").oninput = (e) => { ans.note = e.target.value; saveDraft(); };
      document.getElementById("cancelFault").onclick = () => { ans.result = null; ans.faultPhotos = []; ans.note = ""; viewStep(); };
      document.getElementById("saveFault").onclick = () => {
        ans.note = document.getElementById("note").value.trim();
        if (!ans.note) return toast("Describe the fault");
        if (!ans.faultPhotos.length) return toast("Take a photo of the fault");
        ans.answeredAt = new Date().toISOString();
        advance();
      };
    }
  }
  function bindThumbs(id, photos) {
    const el = document.getElementById(id); if (!el) return;
    el.onclick = (e) => { const i = e.target.dataset.i; if (i != null) lightbox(photos[i].full || photos[i].thumb); };
  }
  function lightbox(src) {
    const lb = document.createElement("div"); lb.className = "lightbox"; lb.innerHTML = `<img src="${src}">`;
    lb.onclick = () => lb.remove(); document.body.appendChild(lb);
  }
  function advance() {
    const d = S.draft;
    if (d.idx < d.steps.length - 1) { d.idx++; saveDraft(); viewStep(); }
    else { d.idx = d.steps.length - 1; saveDraft(); viewReview(); }
  }

  // ---------- photos ----------
  let photoCb = null, photoKind = "";
  function takePhoto(kind, cb) { photoCb = cb; photoKind = kind; $camera.value = ""; $camera.click(); }
  $camera.onchange = async () => {
    const f = $camera.files[0]; if (!f || !photoCb) return;
    if (f.lastModified && Date.now() - f.lastModified > 10 * 60e3) {
      toast("That photo is old. Take a new photo with the camera now.", 4000); return;
    }
    try {
      const p = await processPhoto(f);
      const cb = photoCb; photoCb = null; cb(p);
      uploadPhoto(p, photoKind).catch(() => {}); // upload now; retried at submit if offline
    } catch { toast("Couldn't read that photo – try again"); }
  };
  async function processPhoto(file) {
    const url = URL.createObjectURL(file);
    const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
    const scale = Math.min(1, 1280 / Math.max(img.width, img.height));
    const w = Math.round(img.width * scale), hgt = Math.round(img.height * scale);
    const c = document.createElement("canvas"); c.width = w; c.height = hgt;
    const x = c.getContext("2d"); x.drawImage(img, 0, 0, w, hgt);
    // burn-in stamp: truck, operator, date & time
    const stamp = `${S.draft?.truckId || ""} · ${S.name} · ${new Date().toLocaleString("en-GB")}`;
    const fs = Math.max(14, Math.round(w / 40));
    x.fillStyle = "rgba(0,0,0,.6)"; x.fillRect(0, hgt - fs * 1.8, w, fs * 1.8);
    x.fillStyle = "#ffc400"; x.font = `bold ${fs}px sans-serif`; x.fillText(stamp, fs * 0.6, hgt - fs * 0.6);
    URL.revokeObjectURL(url);
    const full = c.toDataURL("image/jpeg", 0.72);
    const t = document.createElement("canvas"); const ts = 180 / Math.max(w, hgt);
    t.width = Math.round(w * ts); t.height = Math.round(hgt * ts); t.getContext("2d").drawImage(c, 0, 0, t.width, t.height);
    return { id: null, full, thumb: t.toDataURL("image/jpeg", 0.6), at: new Date().toISOString() };
  }
  async function uploadPhoto(p, kind) {
    if (p.id) return p.id;
    if (!p.full) throw new Error("Photo lost – please retake it");
    const r = await api("photos", { body: { data: p.full, kind } });
    p.id = r.id; delete p.full; saveDraft();
    return p.id;
  }

  // ---------- review & submit ----------
  function viewReview() {
    const d = S.draft;
    const faults = d.steps.map((s, i) => ({ s, a: d.answers[i] })).filter((x) => x.a?.result === "FAULT");
    const crit = faults.some((f) => f.s.critical);
    $title.textContent = d.truckId + " · finish";
    h(`
      <div class="progress"><div style="width:100%"></div></div>
      <div class="card">
        <h1>Nearly done</h1>
        ${faults.length ? `<div class="banner ${crit ? "bad" : "warn"}">${faults.length} fault(s) found:<ul style="margin:6px 0 0;padding-left:18px">${faults.map((f) => `<li>${esc(f.s.text)}${f.s.critical ? " <b>(safety critical)</b>" : ""}</li>`).join("")}</ul></div>` : `<div class="banner ok">No faults found.</div>`}
        <label class="f" for="comments">Any other comments? (optional)</label>
        <textarea id="comments" class="in">${esc(d.comments || "")}</textarea>
        <label class="row" style="margin-top:14px;align-items:flex-start;gap:12px">
          <input type="checkbox" id="decl" style="width:26px;height:26px;flex:0 0 26px;margin-top:2px">
          <span style="flex:1">I have carried out all of these checks myself on this truck, and my answers are true.</span>
        </label>
      </div>
      <p id="err" class="banner bad hidden"></p>
      <button class="btn big yellow" id="submit">Submit check</button>
      <button class="btn ghost" id="prev" style="margin-top:10px">← Back</button>`);
    document.getElementById("comments").oninput = (e) => { d.comments = e.target.value; saveDraft(); };
    document.getElementById("prev").onclick = () => viewStep();
    document.getElementById("submit").onclick = submit;
  }

  async function submit() {
    const d = S.draft;
    const btn = document.getElementById("submit"); const errEl = document.getElementById("err");
    if (!document.getElementById("decl").checked) return toast("Tick the declaration to submit");
    btn.disabled = true; errEl.classList.add("hidden");
    try {
      const all = [];
      Object.entries(d.answers).forEach(([, a]) => { (a.photos || []).forEach((p) => all.push([p, "spot"])); (a.faultPhotos || []).forEach((p) => all.push([p, "fault"])); });
      let done = 0;
      for (const [p, kind] of all) { btn.textContent = `Uploading photos ${++done}/${all.length}…`; await uploadPhoto(p, kind); }
      btn.textContent = "Submitting…";
      const truckStep = d.steps.findIndex((s) => s.id === "__truck");
      const items = d.steps.map((s, i) => ({ s, a: d.answers[i] || {} })).filter((x) => !x.s.photoOnly).map(({ s, a }) => ({
        id: s.id, section: s.section, text: s.text, critical: s.critical, result: a.result || "OK", note: a.note || "",
        photoIds: [...(a.photos || []), ...(a.faultPhotos || [])].map((p) => p.id), spotPhoto: !!s.spotPhoto, answeredAt: a.answeredAt || "",
      }));
      const unanswered = d.steps.findIndex((s, i) => !s.photoOnly && !d.answers[i]?.result);
      if (unanswered >= 0) { d.idx = unanswered; toast("One item wasn't answered"); return viewStep(); }
      const r = await api("checks", { body: {
        truckId: d.truckId, shift: d.shift, hours: d.hours, startedAt: d.startedAt, items, declaration: true,
        comments: d.comments || "", wholeTruckRequested: d.wholeTruck,
        wholeTruckPhotoId: truckStep >= 0 ? d.answers[truckStep]?.photos?.[0]?.id || "" : "",
      } });
      S.draft = null; saveDraft();
      viewResult(r.outcome);
    } catch (e) {
      errEl.textContent = e.message + " – check your signal and press Submit again."; errEl.classList.remove("hidden");
      btn.disabled = false; btn.textContent = "Submit check";
    }
  }

  function viewResult(outcome) {
    $title.textContent = "Check submitted";
    const map = {
      PASS: ["ok", "✔ SAFE TO USE", "Check passed. Have a safe shift."],
      FAULT_REPORTED: ["warn", "⚠ FAULT REPORTED", "Minor fault logged and sent to your supervisor. The truck can be used – take extra care and tell your supervisor if it gets worse."],
      DO_NOT_USE: ["bad", "⛔ DO NOT USE", "A safety-critical fault has been reported. Remove the key, tag the truck out of use and tell your supervisor now."],
    };
    const [cls, big, msg] = map[outcome] || map.PASS;
    h(`<div class="result ${cls}"><div class="big">${big}</div><p style="font-size:18px;margin:14px 0 0">${msg}</p></div>
       <button class="btn big" id="home" style="margin-top:16px">Done</button>`);
    if (navigator.vibrate) navigator.vibrate(outcome === "DO_NOT_USE" ? [200, 100, 200, 100, 200] : 120);
    document.getElementById("home").onclick = viewHome;
  }

  // ---------- boot ----------
  function start() {
    const qTruck = new URLSearchParams(location.search).get("truck");
    if (qTruck) { history.replaceState(null, "", "/"); }
    if (!S.token) { if (qTruck) ls.set("mhe_pending_truck", qTruck); return viewLogin(); }
    const pending = qTruck || ls.get("mhe_pending_truck");
    ls.del("mhe_pending_truck");
    viewHome();
    if (pending && S.shift) openTruck(truckFromText(pending));
  }
  start();
  if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => {});
})();
