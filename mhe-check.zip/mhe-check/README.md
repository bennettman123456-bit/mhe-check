# MHE Start-of-Shift Pre-Use Check

Two apps on one Netlify site:

| Who | Address | What it does |
|---|---|---|
| Operators | `https://YOUR-SITE.netlify.app/` | PIN log-in → scan truck QR → pre-use checklist → submit |
| Supervisors / managers | `https://YOUR-SITE.netlify.app/manager.html` | Dashboard, check history, faults, fleet & QR labels, operators |

## Set it up (about 15 minutes)

> Netlify's drag-and-drop upload **won't work** for this app because it has a small server part (to save checks and photos). Use GitHub as below. It's free.

1. **Put the files on GitHub**
   - Sign in at github.com → **New repository** → name it `mhe-check` → Private → Create.
   - Click **uploading an existing file** and drag in *everything inside* this folder (`public`, `netlify`, `netlify.toml`, `package.json`, `README.md`) → **Commit changes**.
2. **Connect it to Netlify**
   - app.netlify.com → **Add new site → Import an existing project → GitHub** → pick `mhe-check`.
   - Leave the build settings as they are (they come from `netlify.toml`) → **Deploy**.
3. **Set the manager password**
   - In the site: **Site configuration → Environment variables → Add a variable**
     - `MANAGER_PASSWORD` = the password supervisors will use
     - `AUTH_SECRET` = any long random string (e.g. mash the keyboard for 40 characters)
   - Go to **Deploys → Trigger deploy → Deploy site** so the password takes effect.
4. **First use**
   - Open `/manager.html`, log in with your name + the password.
   - **Fleet & QR labels**: add every truck (ID like `FLX-01`, `RT-03`, `CB-02`, `PPT-07`) and choose its type.
   - Tick trucks → **Print QR labels**. Laminate and stick one on each truck where the operator sees it before getting on.
   - **Operators**: add each operator with their own 4–8 digit PIN (and licence/training notes).
5. **Operators**: open the site on the phone/handheld → browser menu → **Add to Home Screen**. They can scan with the app's **Scan** button *or* just point the phone's normal camera at the label, which opens the right truck.

## How it works

**Operator check**
- Chooses shift, scans the truck, enters the hour meter reading.
- Answers every item one at a time: **OK / Fault / N/A** (N/A only where an item may not be fitted).
- **Random photo checks:** each check picks 1–3 random items that need a photo before the operator can answer. About 1 in 3 checks also asks for a photo of the whole truck at a random point. Operators can't tell in advance which items will come up.
- **Faults need a description and at least one photo.**
- Photos are stamped with the truck, operator name, date and time. Old gallery photos are rejected.
- If items are tapped through too quickly, the app tells the operator to slow down.
- Result screen:
  - ✔ **SAFE TO USE** when nothing fails.
  - ⚠ **FAULT REPORTED** for a minor fault.
  - ⛔ **DO NOT USE** for any safety-critical fault.
- When a truck has an open critical fault or has been taken off road, the next operator who scans it gets a red warning.

**Manager portal**
- **Dashboard:** covers every truck for the day. It shows who checked each one, when, on which shift and the result. It also counts trucks not checked, trucks not to be used, open faults and **rushed checks** (under 2½ minutes). It refreshes every minute and you can step back through past days.
- **Checks:** filter by date, truck, operator or result. Open any check to see every answer with its time and all photos. **Export CSV** for audits.
- **Faults:** open faults with photos. To close one, enter what was done to fix it (for example "engineer replaced horn, job 1234"). Closing it puts the truck back in service.
- **Fleet:** add, edit or delete trucks. **Take off road** blocks the check and shows the reason to operators. QR labels print from here.
- **Operators:** add operators, reset PINs, disable leavers. Past checks are kept.

## Changing the checklists
All check items are in `public/checklists.js`, grouped by truck type. Each item can be marked:
- `critical: true`: a fault stops use of the truck.
- `na: true`: the operator may answer N/A.

You can also change the spot-photo rules (`SPOT_PHOTOS`), the rushed-check time (`RUSHED_SECONDS`) and the shift names (`SHIFTS`). Edit the file on GitHub and Netlify redeploys on its own.

The items are based on HSE **L117** *Rider-operated lift trucks – operator training and safe use* (pre-use checks) and PUWER/LOLER duties. **Check them against each truck's manufacturer handbook and your site risk assessment**, and add anything specific to your trucks. This app records daily pre-use checks. It does **not** replace LOLER thorough examinations or planned servicing.

## Data
Checks, faults and photos are stored in your own Netlify site (Netlify Blobs). Nothing is sent to anyone else. Photos are compressed to about 150–250 KB each.
