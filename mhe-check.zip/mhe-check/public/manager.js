/* MHE Check Portal – manager / supervisor */
(function () {
  const { TYPES, RUSHED_SECONDS } = window.MHE;
  const $app = document.getElementById("app");
  const $tabs = document.getElementById("tabs");
  const $who = document.getElementById("who");
  const $logout = document.getElementById("logoutBtn");

  const ls = {
    get(k, d = null) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
    del(k) { try { localStorage.removeItem(k); } catch {} },
  };
  const S = { token: ls.get("mhe_mgr_token"), name: ls.get("mhe_mgr_name"), tab: "dash", timer: null, lastChecks: [] };

  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const h = (html) => { $app.innerHTML = html; };
  const today = () => new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/London" }).format(new Date());
  const addDays = (ymd, n) => { const d = new Date(ymd + "T12:00:00Z"); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
  const fmtDT = (iso) => iso ? new Date(iso).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }) : "";
  const fmtT = (iso) => iso ? new Date(iso).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }) : "";
  const dur = (s) => `${Math.floor(s / 60)}m ${String(s % 60).padStart(2, "0")}s`;
  const photo = (id) => `/api/photos/${encodeURIComponent(id)}?t=${encodeURIComponent(S.token)}`;
  const typeLabel = (t) => TYPES[t]?.label || t || "–";
  function toast(msg) { const t = document.createElement("div"); t.className = "toast"; t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), 2600); }

  async function api(path, opts = {}) {
    const res = await fetch("/api/" + path, {
      method: opts.method || (opts.body ? "POST" : "GET"),
      headers: { "content-type": "application/json", ...(S.token ? { authorization: "Bearer " + S.token } : {}) },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && !path.startsWith("login")) { logout(); throw new Error("Session expired"); }
    if (!res.ok) throw new Error(data.error || "Error " + res.status);
    return data;
  }

  const outcomePill = (o) => ({
    PASS: `<span class="pill ok">PASS</span>`,
    FAULT_REPORTED: `<span class="pill warn">FAULT</span>`,
    DO_NOT_USE: `<span class="pill bad">DO NOT USE</span>`,
  }[o] || `<span class="pill grey">${esc(o)}</span>`);
  const statusPill = (s) => ({
    OK: `<span class="pill ok">IN SERVICE</span>`,
    MINOR_FAULTS: `<span class="pill warn">MINOR FAULTS</span>`,
    DO_NOT_USE: `<span class="pill bad">DO NOT USE</span>`,
    OFF_ROAD: `<span class="pill dark">OFF ROAD</span>`,
  }[s] || "");
  const flags = (c) => [
    c.durationSec < RUSHED_SECONDS ? `<span class="pill bad" title="Completed in under ${RUSHED_SECONDS}s">RUSHED ${dur(c.durationSec)}</span>` : "",
  ].join(" ");

  // ---------- auth ----------
  function logout() { ls.del("mhe_mgr_token"); S.token = null; clearInterval(S.timer); viewLogin(); }
  $logout.onclick = logout;

  function viewLogin() {
    $tabs.classList.add("hidden"); $logout.classList.add("hidden"); $who.textContent = "";
    $app.style.maxWidth = "460px";
    h(`<div class="card"><h1>Manager log in</h1>
      <div class="stack">
        <div><label class="f" for="n">Your name</label><input id="n" class="in" value="${esc(S.name || "")}" autocomplete="name"></div>
        <div><label class="f" for="p">Portal password</label><input id="p" type="password" class="in" autocomplete="current-password"></div>
        <p id="err" class="banner bad hidden"></p>
        <button class="btn yellow" id="go">Log in</button>
      </div></div>
      <p class="center small muted"><a href="/">← Operator check app</a></p>`);
    const go = async () => {
      try {
        const r = await api("login/manager", { body: { name: document.getElementById("n").value, password: document.getElementById("p").value } });
        S.token = r.token; S.name = r.name; ls.set("mhe_mgr_token", r.token); ls.set("mhe_mgr_name", r.name);
        boot();
      } catch (e) { const el = document.getElementById("err"); el.textContent = e.message; el.classList.remove("hidden"); }
    };
    document.getElementById("go").onclick = go;
    document.getElementById("p").onkeydown = (e) => { if (e.key === "Enter") go(); };
  }

  $tabs.onclick = (e) => { const t = e.target.dataset.t; if (t) show(t); };
  function show(t) {
    S.tab = t; clearInterval(S.timer);
    [...$tabs.children].forEach((b) => b.classList.toggle("on", b.dataset.t === t));
    ({ dash: viewDash, checks: viewChecks, faults: viewFaults, fleet: viewFleet, ops: viewOps })[t]();
  }
  const loading = () => h(`<div class="card center muted">Loading…</div>`);
  const fail = (e) => h(`<div class="banner bad">${esc(e.message)}</div>`);

  // ---------- dashboard ----------
  async function viewDash(date) {
    date = date || S.dashDate || today(); S.dashDate = date;
    if (!$app.querySelector("#dash")) loading();
    let d; try { d = await api("dashboard?date=" + date); } catch (e) { return fail(e); }
    const byTruck = {}; d.checks.forEach((c) => (byTruck[c.truckId] = byTruck[c.truckId] || []).push(c));
    const checkedTrucks = d.trucks.filter((t) => byTruck[t.id]).length;
    const rushed = d.checks.filter((c) => c.durationSec < RUSHED_SECONDS).length;
    const dnu = d.trucks.filter((t) => t.status === "DO_NOT_USE" || t.status === "OFF_ROAD").length;
    const isToday = date === d.today;
    h(`<div id="dash">
      <div class="section-h"><h2>${isToday ? "Today" : new Date(date).toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" })}</h2>
        <div class="row" style="flex:0 0 auto;gap:6px">
          <button class="btn sm ghost" id="prevD">←</button>
          <input type="date" id="date" class="in" value="${date}" style="padding:8px;font-size:15px;width:auto">
          <button class="btn sm ghost" id="nextD" ${isToday ? "disabled" : ""}>→</button>
        </div></div>
      <div class="kpis">
        <div class="kpi ${checkedTrucks === d.trucks.length && d.trucks.length ? "ok" : ""}"><div class="v">${checkedTrucks}/${d.trucks.length}</div><div class="l">Trucks checked</div></div>
        <div class="kpi"><div class="v">${d.checks.length}</div><div class="l">Checks submitted</div></div>
        <div class="kpi ${dnu ? "bad" : "ok"}"><div class="v">${dnu}</div><div class="l">Trucks not to be used</div></div>
        <div class="kpi ${d.openFaults ? "warn" : "ok"}"><div class="v">${d.openFaults}</div><div class="l">Open faults (${d.criticalFaults} critical)</div></div>
        <div class="kpi ${rushed ? "bad" : "ok"}"><div class="v">${rushed}</div><div class="l">Rushed checks (&lt; ${RUSHED_SECONDS}s)</div></div>
      </div>
      ${d.trucks.length ? "" : `<div class="banner info">No trucks yet – add your fleet in <b>Fleet &amp; QR labels</b>, then add operators.</div>`}
      <div class="grid">${d.trucks.map((t) => {
        const cs = byTruck[t.id] || [];
        const cls = t.status === "DO_NOT_USE" || t.status === "OFF_ROAD" ? "dnu" : cs.some((c) => c.outcome !== "PASS") || t.status === "MINOR_FAULTS" ? "fault" : cs.length ? "checked" : "";
        return `<div class="tcard ${cls}">
          <div class="row" style="justify-content:space-between"><h3 style="flex:0 1 auto">${esc(t.id)}</h3><span style="flex:0 0 auto">${statusPill(t.status)}</span></div>
          <div class="small muted">${esc(typeLabel(t.type))}${t.name ? " · " + esc(t.name) : ""}</div>
          <div style="margin-top:8px">${cs.length ? cs.map((c) => `<div class="list-item small click" data-check="${c.id}" style="cursor:pointer">
              <span>${fmtT(c.submittedAt)} · ${esc(c.operatorName)} · ${esc(c.shift)} ${flags(c)}</span><span>${outcomePill(c.outcome)}</span></div>`).join("")
            : `<div class="small muted">No check ${isToday ? "yet today" : "this day"}</div>`}</div>
        </div>`; }).join("")}</div>
      <p class="small muted" style="margin-top:14px">${isToday ? "Auto-refreshes every minute." : ""}</p></div>`);
    document.getElementById("date").onchange = (e) => viewDash(e.target.value);
    document.getElementById("prevD").onclick = () => viewDash(addDays(date, -1));
    document.getElementById("nextD").onclick = () => viewDash(addDays(date, 1));
    $app.querySelectorAll("[data-check]").forEach((el) => (el.onclick = () => openCheck(el.dataset.check)));
    clearInterval(S.timer);
    if (isToday) S.timer = setInterval(() => { if (S.tab === "dash" && !document.querySelector(".modal")) viewDash(); }, 60000);
  }

  // ---------- checks ----------
  async function viewChecks() {
    const f = S.cf || (S.cf = { from: addDays(today(), -6), to: today(), truck: "", op: "", outcome: "" });
    h(`<div class="section-h"><h2>Check history</h2><button class="btn sm" id="csv">⬇ Export CSV</button></div>
      <div class="filters card" style="padding:12px">
        <div><label class="f">From</label><input type="date" id="from" class="in" value="${f.from}"></div>
        <div><label class="f">To</label><input type="date" id="to" class="in" value="${f.to}"></div>
        <div><label class="f">Truck</label><input id="truck" class="in" value="${esc(f.truck)}" placeholder="Any"></div>
        <div><label class="f">Operator</label><input id="op" class="in" value="${esc(f.op)}" placeholder="Any"></div>
        <div><label class="f">Result</label><select id="outcome" class="in">
          ${[["", "Any"], ["PASS", "Pass"], ["FAULT_REPORTED", "Fault"], ["DO_NOT_USE", "Do not use"], ["RUSHED", "Rushed"]].map(([v, l]) => `<option value="${v}" ${f.outcome === v ? "selected" : ""}>${l}</option>`).join("")}
        </select></div>
        <div style="flex:0 0 auto;min-width:0"><button class="btn sm yellow" id="apply">Search</button></div>
      </div>
      <div id="results" class="card center muted">Loading…</div>`);
    const read = () => ["from", "to", "truck", "op", "outcome"].forEach((k) => (f[k] = document.getElementById(k).value.trim()));
    document.getElementById("apply").onclick = () => { read(); load(); };
    document.getElementById("csv").onclick = () => exportCsv(S.lastChecks);
    async function load() {
      const box = document.getElementById("results");
      box.className = "card center muted"; box.textContent = "Loading…";
      let list; try { list = await api(`checks?from=${f.from}&to=${f.to}`); } catch (e) { box.textContent = e.message; return; }
      list = list.filter((c) =>
        (!f.truck || c.truckId.toLowerCase().includes(f.truck.toLowerCase())) &&
        (!f.op || c.operatorName.toLowerCase().includes(f.op.toLowerCase())) &&
        (!f.outcome || (f.outcome === "RUSHED" ? c.durationSec < RUSHED_SECONDS : c.outcome === f.outcome)));
      S.lastChecks = list;
      box.className = "tablewrap";
      box.innerHTML = list.length ? `<table><thead><tr><th>Date / time</th><th>Truck</th><th>Operator</th><th>Shift</th><th>Hours</th><th>Took</th><th>Faults</th><th>Photos</th><th>Result</th></tr></thead><tbody>
        ${list.map((c) => `<tr class="click" data-id="${c.id}"><td>${fmtDT(c.submittedAt)}</td><td><b>${esc(c.truckId)}</b><div class="small muted">${esc(typeLabel(c.truckType))}</div></td>
        <td>${esc(c.operatorName)}</td><td>${esc(c.shift)}</td><td>${esc(c.hours)}</td><td>${dur(c.durationSec)} ${flags(c)}</td><td>${c.faultCount}</td><td>${c.photoCount}</td><td>${outcomePill(c.outcome)}</td></tr>`).join("")}
        </tbody></table><p class="small muted">${list.length} check(s)</p>` : `<div class="card center muted">No checks found.</div>`;
      box.querySelectorAll("tr[data-id]").forEach((tr) => (tr.onclick = () => openCheck(tr.dataset.id)));
    }
    load();
  }

  function exportCsv(list) {
    if (!list.length) return toast("Nothing to export");
    const cols = [["Submitted", (c) => new Date(c.submittedAt).toLocaleString("en-GB")], ["Truck", (c) => c.truckId], ["Type", (c) => typeLabel(c.truckType)],
      ["Operator", (c) => c.operatorName], ["Shift", (c) => c.shift], ["Hours", (c) => c.hours], ["Duration (s)", (c) => c.durationSec],
      ["Faults", (c) => c.faultCount], ["Photos", (c) => c.photoCount], ["Result", (c) => c.outcome], ["Comments", (c) => c.comments], ["Check ID", (c) => c.id]];
    const q = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const csv = [cols.map((c) => q(c[0])).join(","), ...list.map((r) => cols.map((c) => q(c[1](r))).join(","))].join("\r\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = `mhe-checks-${S.cf?.from || ""}-to-${S.cf?.to || ""}.csv`; a.click();
  }

  function modal(html) {
    const m = document.createElement("div"); m.className = "modal";
    m.innerHTML = `<div class="box">${html}</div>`;
    m.onclick = (e) => { if (e.target === m || e.target.dataset.close != null) m.remove(); };
    document.body.appendChild(m); return m;
  }
  function lightbox(src) { const lb = document.createElement("div"); lb.className = "lightbox"; lb.innerHTML = `<img src="${src}">`; lb.onclick = () => lb.remove(); document.body.appendChild(lb); }
  document.addEventListener("click", (e) => { const src = e.target.dataset?.full; if (src) lightbox(src); });
  const thumbs = (ids) => ids?.length ? `<div class="thumbs">${ids.map((id) => `<img src="${photo(id)}" data-full="${photo(id)}" loading="lazy" alt="photo">`).join("")}</div>` : "";

  async function openCheck(id) {
    const m = modal(`<div class="center muted">Loading…</div>`);
    let c; try { c = await api("checks/" + id); } catch (e) { m.querySelector(".box").innerHTML = esc(e.message); return; }
    let lastSection = "";
    const spotTaken = c.items.filter((i) => i.spotPhoto && i.photoIds.length).length + (c.wholeTruckPhotoId ? 1 : 0);
    m.querySelector(".box").innerHTML = `
      <div class="section-h"><h2>${esc(c.truckId)} – ${esc(typeLabel(c.truckType))}</h2><button class="btn sm ghost" data-close>Close ✕</button></div>
      <div class="card">
        <div style="display:flex;flex-wrap:wrap;gap:6px">${outcomePill(c.outcome)} ${flags(c)} ${c.declaration ? `<span class="pill ok">DECLARATION SIGNED</span>` : ""}</div>
        <div class="formgrid small" style="margin-top:12px">
          <div><b>Operator</b><br>${esc(c.operatorName)}</div><div><b>Shift</b><br>${esc(c.shift)}</div>
          <div><b>Started</b><br>${fmtDT(c.startedAt)}</div><div><b>Submitted</b><br>${fmtDT(c.submittedAt)}</div>
          <div><b>Time taken</b><br>${dur(c.durationSec)}</div><div><b>Hour meter</b><br>${esc(c.hours)}</div>
          <div><b>Spot-check photos</b><br>${spotTaken} of ${c.spotRequested} taken</div><div><b>Check ID</b><br>${esc(c.id)}</div>
        </div>
        ${c.comments ? `<p><b>Comments:</b> ${esc(c.comments)}</p>` : ""}
        ${c.wholeTruckPhotoId ? `<p class="small"><b>Random whole-truck photo:</b></p>${thumbs([c.wholeTruckPhotoId])}` : ""}
      </div>
      <div class="tablewrap"><table><thead><tr><th>Item</th><th>Result</th><th>Notes / photos</th></tr></thead><tbody>
      ${c.items.map((i) => {
        const sec = i.section !== lastSection ? `<tr><th colspan="3">${esc((lastSection = i.section))}</th></tr>` : "";
        return sec + `<tr><td>${esc(i.text)} ${i.critical ? `<span class="pill bad">CRITICAL</span>` : ""} ${i.spotPhoto ? `<span class="pill dark">📸 SPOT</span>` : ""}
          <div class="small muted">${fmtT(i.answeredAt)}</div></td>
          <td class="res-${i.result}">${i.result === "NA" ? "N/A" : i.result}</td><td>${esc(i.note)}${thumbs(i.photoIds)}</td></tr>`; }).join("")}
      </tbody></table></div>
      <p class="small muted">Device: ${esc(c.device)}</p>`;
  }

  // ---------- faults ----------
  async function viewFaults() {
    const status = S.faultStatus || "open";
    h(`<div class="section-h"><h2>Faults</h2>
      <select id="fs" class="in" style="width:auto;padding:8px"><option value="open" ${status === "open" ? "selected" : ""}>Open faults</option><option value="all" ${status === "all" ? "selected" : ""}>Open + resolved (last 2 months)</option></select></div>
      <div id="fl" class="card center muted">Loading…</div>`);
    document.getElementById("fs").onchange = (e) => { S.faultStatus = e.target.value; viewFaults(); };
    let list; try { list = await api("faults?status=" + status); } catch (e) { return fail(e); }
    const box = document.getElementById("fl"); box.className = "";
    if (!list.length) { box.innerHTML = `<div class="banner ok">No open faults 👍</div>`; return; }
    box.innerHTML = list.map((f) => `
      <div class="card" style="border-left:6px solid ${f.status === "resolved" ? "var(--ok)" : f.critical ? "var(--bad)" : "#d97706"}">
        <div class="section-h"><h2>${esc(f.truckId)} – ${esc(f.itemText)}</h2>
          <span>${f.status === "resolved" ? `<span class="pill ok">RESOLVED</span>` : f.critical ? `<span class="pill bad">CRITICAL – DO NOT USE</span>` : `<span class="pill warn">MINOR</span>`}</span></div>
        <p style="margin:0 0 6px">${esc(f.note)}</p>
        <div class="small muted">Reported by ${esc(f.reportedBy)} · ${fmtDT(f.reportedAt)} · <a href="#" data-check="${f.checkId}">view check</a></div>
        ${thumbs(f.photoIds)}
        ${f.status === "resolved"
          ? `<div class="banner ok small" style="margin:12px 0 0">Fixed by ${esc(f.resolvedBy)} · ${fmtDT(f.resolvedAt)} – ${esc(f.resolution)}</div>`
          : `<div class="row" style="margin-top:12px"><input class="in" id="r-${f.id}" placeholder="What was done to fix it? (e.g. engineer replaced horn, job 1234)" style="flex:3;font-size:15px;padding:10px"><button class="btn sm ok" data-resolve="${f.id}">Mark fixed</button></div>`}
      </div>`).join("");
    box.querySelectorAll("[data-check]").forEach((a) => (a.onclick = (e) => { e.preventDefault(); openCheck(a.dataset.check); }));
    box.querySelectorAll("[data-resolve]").forEach((b) => (b.onclick = async () => {
      const id = b.dataset.resolve; const resolution = document.getElementById("r-" + id).value.trim();
      if (!resolution) return toast("Say what was done to fix it");
      try { await api(`faults/${id}/resolve`, { body: { resolution } }); toast("Fault closed"); viewFaults(); } catch (e) { toast(e.message); }
    }));
  }

  // ---------- fleet ----------
  async function viewFleet() {
    loading();
    let trucks; try { trucks = await api("trucks"); } catch (e) { return fail(e); }
    const typeOpts = (sel) => Object.entries(TYPES).map(([k, v]) => `<option value="${k}" ${k === sel ? "selected" : ""}>${esc(v.label)}</option>`).join("");
    h(`<div class="section-h"><h2>Fleet</h2><button class="btn sm yellow" id="print">🖨 Print QR labels</button></div>
      <div class="card"><h2 id="formTitle">Add a truck</h2>
        <div class="formgrid">
          <div><label class="f">Truck ID *</label><input id="t_id" class="in" placeholder="e.g. FLX-01" autocapitalize="characters"></div>
          <div><label class="f">Type *</label><select id="t_type" class="in">${typeOpts("")}</select></div>
          <div><label class="f">Fleet name / no.</label><input id="t_name" class="in" placeholder="optional"></div>
          <div><label class="f">Make / model</label><input id="t_make" class="in" placeholder="e.g. Bendi B424"></div>
          <div><label class="f">Serial no.</label><input id="t_serial" class="in"></div>
          <div><label class="f">Area</label><input id="t_loc" class="in" placeholder="e.g. Chilled"></div>
        </div>
        <div class="row" style="margin-top:12px;justify-content:flex-end"><button class="btn sm ghost hidden" id="t_cancel" style="flex:0 0 auto">Cancel</button><button class="btn sm" id="t_save" style="flex:0 0 auto">Save truck</button></div>
      </div>
      <div class="tablewrap"><table><thead><tr><th><input type="checkbox" id="all" title="select all"></th><th>ID</th><th>Type</th><th>Details</th><th>Status</th><th></th></tr></thead><tbody>
      ${trucks.map((t) => `<tr><td><input type="checkbox" class="sel" value="${esc(t.id)}"></td><td><b>${esc(t.id)}</b></td><td>${esc(typeLabel(t.type))}</td>
        <td class="small">${[t.name, t.make, t.serial && "S/N " + t.serial, t.location].filter(Boolean).map(esc).join(" · ")}</td>
        <td>${statusPill(t.status)}${t.offRoadReason && t.offRoad ? `<div class="small muted">${esc(t.offRoadReason)}</div>` : ""}</td>
        <td style="white-space:nowrap"><button class="btn sm ghost" data-edit="${esc(t.id)}">Edit</button>
          <button class="btn sm ghost" data-vor="${esc(t.id)}">${t.offRoad ? "Back in service" : "Take off road"}</button>
          <button class="btn sm ghost" data-del="${esc(t.id)}">Delete</button></td></tr>`).join("") || `<tr><td colspan="6" class="muted center">No trucks yet</td></tr>`}
      </tbody></table></div>
      <div id="printArea" class="card" style="margin-top:16px"><div class="small muted">Tick trucks above (or none for all), then press Print QR labels. Each label links straight to that truck's check – operators can scan it with the app or their phone camera.</div></div>`);
    let editing = null;
    const F = (k) => document.getElementById("t_" + k);
    const fill = (t) => {
      editing = t; F("id").value = t?.id || ""; F("id").disabled = !!t; F("type").value = t?.type || "COUNTERBALANCE";
      F("name").value = t?.name || ""; F("make").value = t?.make || ""; F("serial").value = t?.serial || ""; F("loc").value = t?.location || "";
      document.getElementById("formTitle").textContent = t ? "Edit " + t.id : "Add a truck";
      F("cancel").classList.toggle("hidden", !t);
    };
    fill(null);
    F("cancel").onclick = () => fill(null);
    F("save").onclick = async () => {
      const body = { ...(editing || {}), id: F("id").value, type: F("type").value, name: F("name").value, make: F("make").value, serial: F("serial").value, location: F("loc").value };
      if (!body.id.trim()) return toast("Enter a truck ID");
      try { await api("trucks", { body }); toast("Saved"); viewFleet(); } catch (e) { toast(e.message); }
    };
    $app.querySelectorAll("[data-edit]").forEach((b) => (b.onclick = () => { fill(trucks.find((t) => t.id === b.dataset.edit)); window.scrollTo(0, 0); }));
    $app.querySelectorAll("[data-del]").forEach((b) => (b.onclick = async () => {
      if (!confirm(`Delete ${b.dataset.del}? Its check history is kept.`)) return;
      try { await api("trucks/" + encodeURIComponent(b.dataset.del), { method: "DELETE" }); viewFleet(); } catch (e) { toast(e.message); }
    }));
    $app.querySelectorAll("[data-vor]").forEach((b) => (b.onclick = async () => {
      const t = trucks.find((x) => x.id === b.dataset.vor);
      let reason = "";
      if (!t.offRoad) { reason = prompt(`Why is ${t.id} being taken off road?`); if (reason === null) return; }
      try { await api("trucks", { body: { ...t, offRoad: !t.offRoad, offRoadReason: reason } }); viewFleet(); } catch (e) { toast(e.message); }
    }));
    document.getElementById("all").onchange = (e) => $app.querySelectorAll(".sel").forEach((c) => (c.checked = e.target.checked));
    document.getElementById("print").onclick = async () => {
      const sel = [...$app.querySelectorAll(".sel:checked")].map((c) => c.value);
      const list = trucks.filter((t) => !sel.length || sel.includes(t.id));
      if (!list.length) return toast("Add a truck first");
      try { await ensureQrLib(); } catch { return toast("Couldn't load the QR code tool – check your internet"); }
      document.getElementById("printArea").innerHTML = `<div class="labels">${list.map((t) => {
        const q = window.qrcode(0, "M"); q.addData(`${location.origin}/?truck=${encodeURIComponent(t.id)}`); q.make();
        return `<div class="label"><div class="qr"><img src="${q.createDataURL(10, 20)}" alt="QR ${esc(t.id)}"></div>
          <div class="id">${esc(t.id)}</div><div class="small">${esc(typeLabel(t.type))}</div>
          <div class="strip">SCAN BEFORE USE · DAILY PRE-USE CHECK</div></div>`; }).join("")}</div>`;
      setTimeout(() => window.print(), 300);
    };
  }
  function ensureQrLib() {
    if (window.qrcode) return Promise.resolve();
    return new Promise((res, rej) => { const s = document.createElement("script"); s.src = "https://cdnjs.cloudflare.com/ajax/libs/qrcode-generator/1.4.4/qrcode.min.js"; s.onload = res; s.onerror = rej; document.head.appendChild(s); });
  }

  // ---------- operators ----------
  async function viewOps() {
    loading();
    let ops; try { ops = await api("operators"); } catch (e) { return fail(e); }
    h(`<div class="section-h"><h2>Operators</h2></div>
      <div class="card"><h2 id="oTitle">Add an operator</h2>
        <div class="formgrid">
          <div><label class="f">Name *</label><input id="o_name" class="in"></div>
          <div><label class="f">PIN (4–8 digits) *</label><input id="o_pin" class="in" inputmode="numeric" maxlength="8"></div>
          <div><label class="f">Licence / training notes</label><input id="o_lic" class="in" placeholder="e.g. RTITB CB, Reach – exp 03/2028"></div>
        </div>
        <div class="row" style="margin-top:12px;justify-content:flex-end"><button class="btn sm ghost" id="o_rand" style="flex:0 0 auto">Random PIN</button><button class="btn sm ghost hidden" id="o_cancel" style="flex:0 0 auto">Cancel</button><button class="btn sm" id="o_save" style="flex:0 0 auto">Save operator</button></div>
      </div>
      <div class="tablewrap"><table><thead><tr><th>Name</th><th>PIN</th><th>Licence / training</th><th>Status</th><th></th></tr></thead><tbody>
      ${ops.map((o) => `<tr><td><b>${esc(o.name)}</b></td><td><span class="pin" data-pin="${esc(o.pin)}">••••</span> <a href="#" data-show>show</a></td><td class="small">${esc(o.licence)}</td>
        <td>${o.active === false ? `<span class="pill grey">DISABLED</span>` : `<span class="pill ok">ACTIVE</span>`}</td>
        <td style="white-space:nowrap"><button class="btn sm ghost" data-edit="${o.id}">Edit</button><button class="btn sm ghost" data-toggle="${o.id}">${o.active === false ? "Enable" : "Disable"}</button><button class="btn sm ghost" data-del="${o.id}">Delete</button></td></tr>`).join("") || `<tr><td colspan="5" class="muted center">No operators yet</td></tr>`}
      </tbody></table></div>`);
    let editing = null;
    const O = (k) => document.getElementById("o_" + k);
    const fill = (o) => { editing = o; O("name").value = o?.name || ""; O("pin").value = o?.pin || ""; O("lic").value = o?.licence || ""; document.getElementById("oTitle").textContent = o ? "Edit " + o.name : "Add an operator"; O("cancel").classList.toggle("hidden", !o); };
    O("cancel").onclick = () => fill(null);
    O("rand").onclick = () => { O("pin").value = String(Math.floor(1000 + Math.random() * 9000)); };
    O("save").onclick = async () => {
      try { await api("operators", { body: { ...(editing || {}), name: O("name").value, pin: O("pin").value, licence: O("lic").value } }); toast("Saved"); viewOps(); } catch (e) { toast(e.message); }
    };
    $app.querySelectorAll("[data-show]").forEach((a) => (a.onclick = (e) => { e.preventDefault(); const p = a.previousElementSibling; p.textContent = p.dataset.pin; a.remove(); }));
    $app.querySelectorAll("[data-edit]").forEach((b) => (b.onclick = () => { fill(ops.find((o) => o.id === b.dataset.edit)); window.scrollTo(0, 0); }));
    $app.querySelectorAll("[data-toggle]").forEach((b) => (b.onclick = async () => {
      const o = ops.find((x) => x.id === b.dataset.toggle);
      try { await api("operators", { body: { ...o, active: o.active === false } }); viewOps(); } catch (e) { toast(e.message); }
    }));
    $app.querySelectorAll("[data-del]").forEach((b) => (b.onclick = async () => {
      if (!confirm("Delete this operator? Their past checks are kept.")) return;
      try { await api("operators/" + b.dataset.del, { method: "DELETE" }); viewOps(); } catch (e) { toast(e.message); }
    }));
  }

  function boot() {
    $app.style.maxWidth = "";
    if (!S.token) return viewLogin();
    $tabs.classList.remove("hidden"); $logout.classList.remove("hidden"); $who.textContent = S.name || "";
    show(S.tab);
  }
  boot();
})();
