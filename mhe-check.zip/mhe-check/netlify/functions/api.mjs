// MHE Start-of-Shift Check – backend API (Netlify Functions v2 + Netlify Blobs)
import { getStore as realGetStore } from "@netlify/blobs";
import crypto from "node:crypto";

export const config = { path: "/api/*" };

const TZ = "Europe/London";
const getStore = (...a) => (globalThis.__MOCK_GET_STORE__ || realGetStore)(...a);
const store = () => getStore({ name: "mhe-checks", consistency: "strong" });

// ---------- helpers ----------
const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
const err = (message, status = 400) => json({ error: message }, status);

const localDate = (d = new Date()) => new Intl.DateTimeFormat("en-CA", { timeZone: TZ }).format(d); // YYYY-MM-DD
const rid = (n = 6) => crypto.randomBytes(n).toString("hex");
const clean = (s, max = 500) => String(s ?? "").trim().slice(0, max);
const addDays = (ymd, n) => {
  const d = new Date(ymd + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};
const validYmd = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s || "");

function secret() {
  const s = process.env.AUTH_SECRET || (process.env.MANAGER_PASSWORD ? "mhe:" + process.env.MANAGER_PASSWORD : "");
  return s || "mhe-insecure-dev-secret";
}
function sign(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const mac = crypto.createHmac("sha256", secret()).update(body).digest("base64url");
  return body + "." + mac;
}
function verify(token) {
  if (!token || !token.includes(".")) return null;
  const [body, mac] = token.split(".");
  const expect = crypto.createHmac("sha256", secret()).update(body).digest("base64url");
  if (mac.length !== expect.length || !crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(expect))) return null;
  try {
    const p = JSON.parse(Buffer.from(body, "base64url").toString());
    if (p.exp < Date.now()) return null;
    return p;
  } catch { return null; }
}
function auth(req, url) {
  const h = req.headers.get("authorization") || "";
  const t = h.startsWith("Bearer ") ? h.slice(7) : url.searchParams.get("t");
  return verify(t);
}
function safeEqual(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

async function getList(key) { return (await store().get(key, { type: "json" })) || []; }
async function setList(key, v) { await store().setJSON(key, v); }

async function getMany(keys) {
  const s = store(), out = [];
  for (let i = 0; i < keys.length; i += 25) {
    const chunk = await Promise.all(keys.slice(i, i + 25).map((k) => s.get(k, { type: "json" })));
    out.push(...chunk.filter(Boolean));
  }
  return out;
}
async function listKeys(prefix) {
  const { blobs } = await store().list({ prefix });
  return blobs.map((b) => b.key);
}
async function openFaults() {
  return getMany(await listKeys("faults/open/"));
}

function truckStatus(truck, faults) {
  const mine = faults.filter((f) => f.truckId === truck.id);
  const critical = mine.filter((f) => f.critical);
  let status = "OK";
  if (truck.offRoad) status = "OFF_ROAD";
  else if (critical.length) status = "DO_NOT_USE";
  else if (mine.length) status = "MINOR_FAULTS";
  return { ...truck, status, openFaults: mine.length, criticalFaults: critical.length };
}

function summary(c) {
  const { items, ...rest } = c;
  return {
    ...rest,
    faultCount: items.filter((i) => i.result === "FAULT").length,
    itemCount: items.length,
    photoCount: items.reduce((n, i) => n + (i.photoIds?.length || 0), 0) + (c.wholeTruckPhotoId ? 1 : 0),
  };
}

async function checksBetween(from, to) {
  const keys = [];
  for (let d = from, n = 0; d <= to && n < 62; d = addDays(d, 1), n++) keys.push(...(await listKeys(`checks/${d}/`)));
  const list = await getMany(keys);
  return list.sort((a, b) => (b.submittedAt || "").localeCompare(a.submittedAt || ""));
}

// ---------- route handler ----------
export default async (req) => {
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean);
  const [a, b, c] = parts;
  const m = req.method;
  const body = ["POST", "PUT", "PATCH"].includes(m) ? await req.json().catch(() => ({})) : {};

  try {
    // ----- login -----
    if (a === "login" && m === "POST") {
      if (b === "manager") {
        const pw = process.env.MANAGER_PASSWORD;
        if (!pw) return err("Manager password not set up yet. Add MANAGER_PASSWORD in Netlify → Site configuration → Environment variables.", 500);
        const name = clean(body.name, 60);
        if (!name) return err("Enter your name");
        if (!safeEqual(body.password || "", pw)) return err("Wrong password", 401);
        return json({ token: sign({ r: "mgr", name, exp: Date.now() + 12 * 3600e3 }), name });
      }
      const pin = clean(body.pin, 10);
      const ops = await getList("operators.json");
      const op = ops.find((o) => o.active !== false && o.pin === pin);
      if (!op) return err("PIN not recognised. Ask your supervisor to set you up.", 401);
      return json({ token: sign({ r: "op", id: op.id, name: op.name, exp: Date.now() + 14 * 3600e3 }), name: op.name });
    }

    const user = auth(req, url);
    if (!user) return err("Please log in again", 401);
    const isMgr = user.r === "mgr";
    const mgrOnly = () => (isMgr ? null : err("Managers only", 403));

    // ----- photos -----
    if (a === "photos") {
      if (m === "POST") {
        const data = String(body.data || "");
        const b64 = data.replace(/^data:image\/\w+;base64,/, "");
        const buf = Buffer.from(b64, "base64");
        if (!buf.length || buf.length > 4.5e6) return err("Photo missing or too large");
        const id = "p" + Date.now().toString(36) + rid(4);
        await store().set("photos/" + id, buf, { metadata: { by: user.name, at: new Date().toISOString(), kind: clean(body.kind, 30) } });
        return json({ id });
      }
      if (m === "GET" && b) {
        const r = await store().get("photos/" + b.replace(/[^\w]/g, ""), { type: "arrayBuffer" });
        if (!r) return err("Not found", 404);
        return new Response(r, { headers: { "content-type": "image/jpeg", "cache-control": "private, max-age=86400" } });
      }
    }

    // ----- trucks -----
    if (a === "trucks") {
      const trucks = await getList("trucks.json");
      if (m === "GET" && b) {
        const id = decodeURIComponent(b).toUpperCase();
        const t = trucks.find((x) => x.id.toUpperCase() === id);
        if (!t || t.active === false) return err(`Truck "${id}" isn't registered. Ask a supervisor to add it.`, 404);
        const faults = (await openFaults()).filter((f) => f.truckId === t.id);
        const today = (await getMany(await listKeys(`checks/${localDate()}/`))).filter((x) => x.truckId === t.id).map(summary);
        return json({ truck: truckStatus(t, faults), openFaults: faults, todaysChecks: today });
      }
      if (m === "GET") {
        const faults = await openFaults();
        return json(trucks.map((t) => truckStatus(t, faults)));
      }
      const no = mgrOnly(); if (no) return no;
      if (m === "POST") {
        const id = clean(body.id, 30).toUpperCase().replace(/\s+/g, "-");
        if (!id) return err("Truck ID required");
        const t = {
          id, type: clean(body.type, 20), name: clean(body.name, 60), make: clean(body.make, 60),
          serial: clean(body.serial, 60), location: clean(body.location, 60), active: body.active !== false,
          offRoad: !!body.offRoad, offRoadReason: clean(body.offRoadReason, 200),
        };
        const i = trucks.findIndex((x) => x.id === id);
        if (i >= 0) trucks[i] = { ...trucks[i], ...t }; else trucks.push({ ...t, createdAt: new Date().toISOString() });
        trucks.sort((x, y) => x.id.localeCompare(y.id, undefined, { numeric: true }));
        await setList("trucks.json", trucks);
        return json({ ok: true, truck: t });
      }
      if (m === "DELETE" && b) {
        await setList("trucks.json", trucks.filter((x) => x.id !== decodeURIComponent(b)));
        return json({ ok: true });
      }
    }

    // ----- operators -----
    if (a === "operators") {
      const no = mgrOnly(); if (no) return no;
      const ops = await getList("operators.json");
      if (m === "GET") return json(ops);
      if (m === "POST") {
        const name = clean(body.name, 60);
        const pin = clean(body.pin, 10);
        if (!name) return err("Name required");
        if (!/^\d{4,8}$/.test(pin)) return err("PIN must be 4–8 digits");
        const dup = ops.find((o) => o.pin === pin && o.id !== body.id);
        if (dup) return err("That PIN is already used by " + dup.name);
        if (body.id) {
          const o = ops.find((x) => x.id === body.id);
          if (!o) return err("Not found", 404);
          Object.assign(o, { name, pin, licence: clean(body.licence, 120), active: body.active !== false });
        } else {
          ops.push({ id: "o" + rid(4), name, pin, licence: clean(body.licence, 120), active: true, createdAt: new Date().toISOString() });
        }
        ops.sort((x, y) => x.name.localeCompare(y.name));
        await setList("operators.json", ops);
        return json({ ok: true });
      }
      if (m === "DELETE" && b) {
        await setList("operators.json", ops.filter((o) => o.id !== b));
        return json({ ok: true });
      }
    }

    // ----- checks -----
    if (a === "checks") {
      if (m === "POST") {
        const trucks = await getList("trucks.json");
        const truck = trucks.find((t) => t.id === body.truckId);
        if (!truck) return err("Unknown truck");
        const items = (Array.isArray(body.items) ? body.items : []).slice(0, 120).map((i) => ({
          id: clean(i.id, 40), section: clean(i.section, 60), text: clean(i.text, 300),
          critical: !!i.critical, result: ["OK", "FAULT", "NA"].includes(i.result) ? i.result : "OK",
          note: clean(i.note, 1000), photoIds: (i.photoIds || []).map((p) => clean(p, 40)).slice(0, 5),
          spotPhoto: !!i.spotPhoto, answeredAt: clean(i.answeredAt, 40),
        }));
        if (!items.length) return err("No checklist answers");
        const faults = items.filter((i) => i.result === "FAULT");
        const outcome = faults.some((f) => f.critical) ? "DO_NOT_USE" : faults.length ? "FAULT_REPORTED" : "PASS";
        const now = new Date();
        const day = localDate(now);
        const id = day.replace(/-/g, "") + "-" + rid(4);
        const started = Date.parse(body.startedAt) || now.getTime();
        const check = {
          id, day, truckId: truck.id, truckType: truck.type, truckName: truck.name || "",
          operatorId: user.id, operatorName: user.name, shift: clean(body.shift, 20),
          hours: clean(body.hours, 20), startedAt: new Date(started).toISOString(),
          submittedAt: now.toISOString(), durationSec: Math.max(0, Math.round((now.getTime() - started) / 1000)),
          outcome, items, spotRequested: items.filter((i) => i.spotPhoto).length + (body.wholeTruckRequested ? 1 : 0),
          wholeTruckPhotoId: clean(body.wholeTruckPhotoId, 40), declaration: !!body.declaration,
          comments: clean(body.comments, 1000), device: clean(req.headers.get("user-agent"), 200),
        };
        await store().setJSON(`checks/${day}/${id}`, check);
        for (const f of faults) {
          const fid = "f" + Date.now().toString(36) + rid(3);
          await store().setJSON("faults/open/" + fid, {
            id: fid, truckId: truck.id, truckType: truck.type, checkId: id, itemId: f.id, itemText: f.text,
            critical: f.critical, note: f.note, photoIds: f.photoIds, reportedBy: user.name,
            reportedAt: now.toISOString(), status: "open",
          });
        }
        return json({ ok: true, id, outcome });
      }
      const no = mgrOnly(); if (no) return no;
      if (m === "GET" && b) {
        const day = `${b.slice(0, 4)}-${b.slice(4, 6)}-${b.slice(6, 8)}`;
        const c = await store().get(`checks/${day}/${b}`, { type: "json" });
        return c ? json(c) : err("Not found", 404);
      }
      if (m === "GET") {
        const to = validYmd(url.searchParams.get("to")) ? url.searchParams.get("to") : localDate();
        const from = validYmd(url.searchParams.get("from")) ? url.searchParams.get("from") : addDays(to, -6);
        return json((await checksBetween(from, to)).map(summary));
      }
    }

    // ----- faults -----
    if (a === "faults") {
      const no = mgrOnly(); if (no) return no;
      if (m === "GET") {
        const status = url.searchParams.get("status") || "open";
        let list = await openFaults();
        if (status === "all") {
          const months = [localDate().slice(0, 7), addDays(localDate(), -31).slice(0, 7)];
          for (const mo of [...new Set(months)]) list.push(...(await getMany(await listKeys(`faults/closed/${mo}/`))));
        }
        return json(list.sort((x, y) => (y.reportedAt || "").localeCompare(x.reportedAt || "")));
      }
      if (m === "POST" && b && c === "resolve") {
        const f = await store().get("faults/open/" + b, { type: "json" });
        if (!f) return err("Fault not found or already closed", 404);
        const now = new Date();
        Object.assign(f, { status: "resolved", resolvedBy: user.name, resolvedAt: now.toISOString(), resolution: clean(body.resolution, 1000) });
        if (!f.resolution) return err("Say what was done to fix it");
        await store().setJSON(`faults/closed/${localDate(now).slice(0, 7)}/${b}`, f);
        await store().delete("faults/open/" + b);
        return json({ ok: true });
      }
    }

    // ----- dashboard -----
    if (a === "dashboard" && m === "GET") {
      const no = mgrOnly(); if (no) return no;
      const day = validYmd(url.searchParams.get("date")) ? url.searchParams.get("date") : localDate();
      const [trucks, faults, checks, ops] = await Promise.all([
        getList("trucks.json"), openFaults(), checksBetween(day, day), getList("operators.json"),
      ]);
      return json({
        day, today: localDate(),
        trucks: trucks.filter((t) => t.active !== false).map((t) => truckStatus(t, faults)),
        checks: checks.map(summary),
        openFaults: faults.length,
        criticalFaults: faults.filter((f) => f.critical).length,
        operators: ops.filter((o) => o.active !== false).length,
      });
    }

    if (a === "me") return json(user);
    return err("Not found", 404);
  } catch (e) {
    console.error(e);
    return err("Server error: " + e.message, 500);
  }
};
